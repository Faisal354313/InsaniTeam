-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 15, 2025 at 09:31 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mediapembelajaranaiphp`
--

-- --------------------------------------------------------

--
-- Table structure for table `jawaban`
--

CREATE TABLE `jawaban` (
  `idjawaban` int(11) NOT NULL,
  `idsiswa` int(11) NOT NULL,
  `idkuis` int(11) NOT NULL,
  `benar` varchar(255) NOT NULL,
  `salah` varchar(255) NOT NULL,
  `nilai` varchar(255) NOT NULL,
  `waktu` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jawabandetail`
--

CREATE TABLE `jawabandetail` (
  `idjawabandetail` int(11) NOT NULL,
  `idjawaban` int(11) NOT NULL,
  `idsoal` text NOT NULL,
  `jawaban` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kuis`
--

CREATE TABLE `kuis` (
  `idkuis` int(11) NOT NULL,
  `judul` text NOT NULL,
  `isi` text NOT NULL,
  `tanggal` text NOT NULL,
  `link` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kuis`
--

INSERT INTO `kuis` (`idkuis`, `judul`, `isi`, `tanggal`, `link`) VALUES
(1, 'TRI SUKSES', '', '2025-05-15', '');

-- --------------------------------------------------------

--
-- Table structure for table `materi`
--

CREATE TABLE `materi` (
  `idmateri` int(11) NOT NULL,
  `judul` text NOT NULL,
  `isi` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foto` text NOT NULL,
  `file` text NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `materi`
--

INSERT INTO `materi` (`idmateri`, `judul`, `isi`, `foto`, `file`, `tanggal`) VALUES
(1, 'Tri Sukses', '<p>Menjadi Pribadi yang Sukses dalam Segala Aspek</p>\r\n\r\n<p><strong>1. Akhlaqul Karimah (Akhlak Mulia)</strong>:</p>\r\n\r\n<p>Mengacu pada perilaku yang mencerminkan sifat-sifat baik yang diajarkan oleh Nabi Muhammad SAW, seperti sabar, ramah, dan penuh kasih sayang.</p>\r\n\r\n<p>َما نَّ ِإ ُت ِإ ْ َت ِّمَم ُب ِعث ِق ُأل َأل ْخالَ ِرَم ا ُأل َمَكا</p>\r\n\r\n<p>Artinya: &quot;Sesungguhnya aku diutus hanya untuk menyempurnakan akhlak yang mulia.&quot; (HR.Bukhori)</p>\r\n\r\n<p>أ المؤمنين ا ْكَم ُل إيمان هم ً ْح َسنُ َأ َأ ا خلقً</p>\r\n\r\n<p>Artinya: &ldquo;Mukmin yang paling sempurna keimanannya adalah mereka yang paling baik akhlaknya.&rdquo; [Shahih Abu Dawud no. 4682]</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2. Alim &amp; Faqih (Ilmu dan Pemahaman Agama):</strong></p>\r\n\r\n<p>Generasi muda diharapkan menjadi pribadi yang paham agama dan mampu mengamalkannya dengan baik dalam kehidupan sehari-hari.</p>\r\n\r\n<p>a. Penguasaan ilmu baik ilmu agama maupun ilmu pengetahuan</p>\r\n\r\n<p>َم ْن َراَد َأ َأ َيا الُّدن ْي ِه ْ َفَعلَ ِ م بِال ِعل َو َم ْن َراَد ْ َأ اآل ِخ َرَة ْي ِه َأ َفَعلَ ِ م بِال ِعل َو َم ْن َراَد ُه َما ْ َأ ْي ِه َأ َفَعلَ ِ م بِال ِعلْ</p>\r\n\r\n<p>&ldquo;Barangsiapa yang menginginkan (kebahagiaan) dunia, maka hendaknya dengan ilmu. Dan barangsiapa yang menginginkan (kebahagiaan) akhirat, maka hendaknya dengan ilmu. Dan barangsiapa yang menginginkan (kebahagiaan) dunia akhirat, maka hendaknya dengan ilmu.&rdquo;</p>\r\n\r\n<p>b. Belajar berkelanjutan</p>\r\n\r\n<p>ُب َطلَ ِ م ِعلْ الْ ْي َضةٌ لى ِ ُك َع ِّل َفر َ ٍ ُم ْسلِم</p>\r\n\r\n<p>Artinya: &ldquo;Menuntut ilmu itu wajib bagi setiap muslim.&rdquo; (HR. Muslim)</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>3. <strong>Mandiri:</strong></p>\r\n\r\n<p>Menjadi individu yang tangguh dan tidak bergantung pada orang lain, serta memiliki rasa tanggung jawab terhadap dirinya sendiri.</p>\r\n\r\n<p>ا ِإ َكا َن ِفي ِإذَ ِن آ ِخرِ ِس ُبَّد اَل ال َّز َما ا لِلن ِمَن َّ ِ الَّد َرا ِهم ِ َوالَّدَناِنير ُيِقي ُم ال َّر ُج ُل َها ِ ب ِديَن ُه َياه.ُ َو رواه الطبراني ُدنْ</p>\r\n\r\n<p>Artinya, &ldquo;Ketika akhir zaman sudah tiba, maka tidak bisa tidak (pasti) bagi manusia memiliki dirham dan dinar untuk menegakkan agamnya dan dunianya.&rdquo; (HR at-Thabrani). Contoh Penerapan Mandiri : Mulai dari pelatihan kewirausahaan, penyuluhan kesehatan, workshop hijab syar&rsquo;i, sepak bola, pramuka, workshop Information and Computer Technology (ICT), silat, Camping Cinta Alam Indonesia dll</p>\r\n', 'akla.avif', '', '2025-05-15');

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `telepon` varchar(12) NOT NULL,
  `alamat` text NOT NULL,
  `nowa` text NOT NULL,
  `username` text NOT NULL,
  `level` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id`, `nama`, `email`, `password`, `telepon`, `alamat`, `nowa`, `username`, `level`) VALUES
(2, 'Guru', 'guru@gmail.com', 'guru', '082114299456', '<p>Jl. Sudirman, Jakarta</p>\r\n', '082114299456', 'admin', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `idsiswa` int(11) NOT NULL,
  `nama` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `jeniskelamin` text NOT NULL,
  `tempatlahir` text NOT NULL,
  `tanggallahir` date NOT NULL,
  `alamat` text NOT NULL,
  `asalsekolah` text NOT NULL,
  `foto` text NOT NULL,
  `level` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`idsiswa`, `nama`, `email`, `password`, `jeniskelamin`, `tempatlahir`, `tanggallahir`, `alamat`, `asalsekolah`, `foto`, `level`) VALUES
(1, 'Dewi Uchiha', 'dewi@gmail.com', 'dewi', 'Perempuan', 'Palembang', '2000-05-15', '-', 'SMA Muhammadiyah Palembang', 'default.png', 'Siswa');

-- --------------------------------------------------------

--
-- Table structure for table `soal`
--

CREATE TABLE `soal` (
  `idsoal` int(11) NOT NULL,
  `idkuis` int(11) NOT NULL,
  `soal` text NOT NULL,
  `a` text NOT NULL,
  `b` text NOT NULL,
  `c` text NOT NULL,
  `d` text NOT NULL,
  `kunci` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `soal`
--

INSERT INTO `soal` (`idsoal`, `idkuis`, `soal`, `a`, `b`, `c`, `d`, `kunci`) VALUES
(1, 1, '<p>Tri sukes ada berapa&hellip;..</p>\r\n', '1', '2', '3', '4', 'C'),
(2, 1, '<p>Dibawah ini manakah yang tidak termasuk tri sukses generus&hellip;..</p>\r\n', 'Jujur', 'Akhlaqul Karimah', 'Mandiri', 'Alim Faqih', 'A'),
(3, 1, '<p>Tri sukses terdiri dari 3 poin, berikut manakah yang termasuk dalam tri sukes&hellip;.</p>\r\n', 'Amanah', 'Mandiri', 'Berbuat baik', 'Jujur', 'B');

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE `video` (
  `idvideo` int(11) NOT NULL,
  `judul` text NOT NULL,
  `isi` text NOT NULL,
  `file` text NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `video`
--

INSERT INTO `video` (`idvideo`, `judul`, `isi`, `file`, `tanggal`) VALUES
(1, 'Materi Islam Masa Kini', '<p>-</p>\r\n', '2025-05-15 11-31-11.mp4', '2025-05-15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jawaban`
--
ALTER TABLE `jawaban`
  ADD PRIMARY KEY (`idjawaban`),
  ADD KEY `idsiswa` (`idsiswa`,`idkuis`);

--
-- Indexes for table `jawabandetail`
--
ALTER TABLE `jawabandetail`
  ADD PRIMARY KEY (`idjawabandetail`),
  ADD KEY `idjawaban` (`idjawaban`);

--
-- Indexes for table `kuis`
--
ALTER TABLE `kuis`
  ADD PRIMARY KEY (`idkuis`);

--
-- Indexes for table `materi`
--
ALTER TABLE `materi`
  ADD PRIMARY KEY (`idmateri`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`idsiswa`);

--
-- Indexes for table `soal`
--
ALTER TABLE `soal`
  ADD PRIMARY KEY (`idsoal`),
  ADD KEY `idkuis` (`idkuis`);

--
-- Indexes for table `video`
--
ALTER TABLE `video`
  ADD PRIMARY KEY (`idvideo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jawaban`
--
ALTER TABLE `jawaban`
  MODIFY `idjawaban` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jawabandetail`
--
ALTER TABLE `jawabandetail`
  MODIFY `idjawabandetail` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kuis`
--
ALTER TABLE `kuis`
  MODIFY `idkuis` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `materi`
--
ALTER TABLE `materi`
  MODIFY `idmateri` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `siswa`
--
ALTER TABLE `siswa`
  MODIFY `idsiswa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `soal`
--
ALTER TABLE `soal`
  MODIFY `idsoal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `video`
--
ALTER TABLE `video`
  MODIFY `idvideo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `jawaban`
--
ALTER TABLE `jawaban`
  ADD CONSTRAINT `jawaban_ibfk_1` FOREIGN KEY (`idsiswa`) REFERENCES `siswa` (`idsiswa`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `jawabandetail`
--
ALTER TABLE `jawabandetail`
  ADD CONSTRAINT `jawabandetail_ibfk_1` FOREIGN KEY (`idjawaban`) REFERENCES `jawaban` (`idjawaban`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `soal`
--
ALTER TABLE `soal`
  ADD CONSTRAINT `soal_ibfk_1` FOREIGN KEY (`idkuis`) REFERENCES `kuis` (`idkuis`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

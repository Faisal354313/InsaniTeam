<?php
$koneksi = new mysqli("localhost", "root", "", "mediapembelajaranaiphp");
$koneksi->set_charset("utf8mb4");
